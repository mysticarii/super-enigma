"use client";

import { useEffect, useRef } from "react";
import * as THREE from "three";

function prefersReducedMotion() {
  if (typeof window === "undefined") return true;
  return window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches ?? false;
}

export default function AIVisualCore() {
  const hostRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;

    const reduce = prefersReducedMotion();

    // Scene
    const scene = new THREE.Scene();
    scene.fog = new THREE.Fog(new THREE.Color("#05070f"), 6, 18);

    // Camera
    const camera = new THREE.PerspectiveCamera(55, 1, 0.1, 100);
    camera.position.set(0, 0.3, 7.5);

    // Renderer
    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: "high-performance",
    });
    renderer.setClearColor(0x000000, 0);
    renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
    host.appendChild(renderer.domElement);

    // Lights
    const key = new THREE.DirectionalLight(new THREE.Color("#00fff2"), 1.2);
    key.position.set(3, 4, 5);
    scene.add(key);

    const fill = new THREE.PointLight(new THREE.Color("#d16eff"), 1.2, 30);
    fill.position.set(-3, 0, 6);
    scene.add(fill);

    const rim = new THREE.PointLight(new THREE.Color("#00ffa6"), 1.0, 30);
    rim.position.set(0, -2, 6);
    scene.add(rim);

    // Background Shader Plane (ambient cyber liquid)
    const bgGeom = new THREE.PlaneGeometry(20, 12, 1, 1);
    const bgMat = new THREE.ShaderMaterial({
      transparent: true,
      uniforms: {
        uTime: { value: 0 },
        uA: { value: new THREE.Color("#00fff2") },
        uB: { value: new THREE.Color("#d16eff") },
        uC: { value: new THREE.Color("#00ffa6") },
      },
      vertexShader: `
        varying vec2 vUv;
        void main(){
          vUv = uv;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0);
        }
      `,
      fragmentShader: `
        varying vec2 vUv;
        uniform float uTime;
        uniform vec3 uA; uniform vec3 uB; uniform vec3 uC;

        float noise(vec2 p){
          return sin(p.x)*sin(p.y);
        }

        void main(){
          vec2 uv = vUv;
          uv -= 0.5;
          uv.x *= 1.4;

          float t = uTime * 0.25;

          float n1 = sin((uv.x*3.0 + t) ) * 0.5 + 0.5;
          float n2 = sin((uv.y*4.0 - t*1.3)) * 0.5 + 0.5;
          float n3 = noise(uv*6.0 + t);

          float m = smoothstep(0.0, 1.0, (n1*0.45 + n2*0.35 + n3*0.20));
          vec3 col = mix(uA, uB, m);
          col = mix(col, uC, smoothstep(0.2, 0.9, n2));

          float vignette = smoothstep(0.95, 0.20, length(uv));
          float glow = 0.10 + 0.25 * vignette;

          gl_FragColor = vec4(col, glow);
        }
      `,
      depthWrite: false,
    });

    const bg = new THREE.Mesh(bgGeom, bgMat);
    bg.position.set(0, 0, -7);
    scene.add(bg);

    // Core object
    const coreGroup = new THREE.Group();
    scene.add(coreGroup);

    const coreGeom = new THREE.IcosahedronGeometry(1.35, 2);
    const coreMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color("#0b1025"),
      emissive: new THREE.Color("#00fff2"),
      emissiveIntensity: 0.35,
      metalness: 0.65,
      roughness: 0.22,
    });
    const core = new THREE.Mesh(coreGeom, coreMat);
    coreGroup.add(core);

    // Wire overlay (aura)
    const wire = new THREE.LineSegments(
      new THREE.WireframeGeometry(coreGeom),
      new THREE.LineBasicMaterial({
        color: new THREE.Color("#d16eff"),
        transparent: true,
        opacity: 0.22,
      })
    );
    coreGroup.add(wire);

    // Orbiting nodes + connections
    // NOTE: we intentionally avoid Three.js type annotations here.
    // On some CI environments (e.g., Netlify), TypeScript can fail to
    // resolve Three.js typings depending on install/config. Keeping this
    // file type-light ensures `next build` won't fail due to Three typings.
    const nodes: any[] = [];
    const lines: any[] = [];
    const nodeGeom = new THREE.SphereGeometry(0.07, 16, 16);

    for (let i = 0; i < 16; i++) {
      const mat = new THREE.MeshStandardMaterial({
        color: new THREE.Color("#00fff2"),
        emissive: new THREE.Color(i % 3 === 0 ? "#d16eff" : "#00fff2"),
        emissiveIntensity: 0.8,
        roughness: 0.15,
        metalness: 0.35,
      });

      const n = new THREE.Mesh(nodeGeom, mat);
      coreGroup.add(n);
      nodes.push(n);

      const g = new THREE.BufferGeometry().setFromPoints([
        new THREE.Vector3(0, 0, 0),
        new THREE.Vector3(0, 0, 0),
      ]);
      const m = new THREE.LineBasicMaterial({
        color: new THREE.Color("#00ffa6"),
        transparent: true,
        opacity: 0.20,
      });
      const l = new THREE.Line(g, m);
      coreGroup.add(l);
      lines.push(l);
    }

    // Particle field
    const pCount = 900;
    const pGeom = new THREE.BufferGeometry();
    const pos = new Float32Array(pCount * 3);
    for (let i = 0; i < pCount; i++) {
      pos[i * 3 + 0] = (Math.random() - 0.5) * 16;
      pos[i * 3 + 1] = (Math.random() - 0.5) * 10;
      pos[i * 3 + 2] = (Math.random() - 0.5) * 10;
    }
    pGeom.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    const pMat = new THREE.PointsMaterial({
      size: 0.012,
      color: new THREE.Color("#00fff2"),
      transparent: true,
      opacity: 0.55,
      depthWrite: false,
    });
    const points = new THREE.Points(pGeom, pMat);
    scene.add(points);

    // Resize
    const resize = () => {
      const w = host.clientWidth;
      const h = host.clientHeight;
      camera.aspect = Math.max(1e-6, w / Math.max(1, h));
      camera.updateProjectionMatrix();
      renderer.setSize(w, h, false);
    };
    resize();
    window.addEventListener("resize", resize);

    // Mouse parallax
    const mouse = { x: 0, y: 0 };
    const onMove = (e: PointerEvent) => {
      const r = host.getBoundingClientRect();
      const nx = ((e.clientX - r.left) / r.width) * 2 - 1;
      const ny = ((e.clientY - r.top) / r.height) * 2 - 1;
      mouse.x = nx;
      mouse.y = ny;
    };
    host.addEventListener("pointermove", onMove);

    let t0 = performance.now();
    let raf = 0;

    const renderOnce = () => {
      renderer.render(scene, camera);
    };

    const animate = () => {
      const t = (performance.now() - t0) / 1000;

      (bgMat.uniforms.uTime.value as number) = t;

      core.rotation.y = t * 0.55;
      core.rotation.x = t * 0.18;
      wire.rotation.copy(core.rotation);

      camera.position.x += (mouse.x * 0.45 - camera.position.x) * 0.05;
      camera.position.y += (-mouse.y * 0.22 - camera.position.y) * 0.05;
      camera.lookAt(0, 0, 0);

      for (let i = 0; i < nodes.length; i++) {
        const a = t * (0.55 + i * 0.02) + i;
        const r = 2.2 + (i % 4) * 0.25;
        nodes[i].position.set(
          Math.cos(a) * r * 0.55,
          Math.sin(a * 1.2) * 0.55,
          Math.sin(a) * r * 0.22
        );

        const g = (lines[i] as any).geometry as any;
        const arr = g.attributes.position as any;
        arr.setXYZ(0, 0, 0, 0);
        arr.setXYZ(1, nodes[i].position.x, nodes[i].position.y, nodes[i].position.z);
        arr.needsUpdate = true;
      }

      points.rotation.y = t * 0.03;

      renderer.render(scene, camera);
      raf = requestAnimationFrame(animate);
    };

    if (reduce) renderOnce();
    else animate();

    return () => {
      cancelAnimationFrame(raf);
      host.removeEventListener("pointermove", onMove);
      window.removeEventListener("resize", resize);
      renderer.dispose();
      if (renderer.domElement.parentElement === host) host.removeChild(renderer.domElement);
    };
  }, []);

  return <div ref={hostRef} className="aiVisualCore" aria-hidden="true" />;
}
