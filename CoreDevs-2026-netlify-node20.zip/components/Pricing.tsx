import Link from "next/link";

export default function Pricing() {
  return (
    <section id="pricing">
      <div className="container">
        <div className="section-header">
          <h2 className="section-title">
            <span className="highlight">پلن‌ها</span> و شروع سریع
          </h2>
          <p className="section-subtitle">
            پلن‌ها نمونه‌اند. قیمت نهایی به حجم پیام‌ها/سفارش‌ها و سطح اتصال‌ها بستگی دارد. پرداخت ریالی/تومانی در این نسخه ارائه نمی‌شود.
          </p>
        </div>

        <div className="pricingGrid">
          <div className="priceCard">
            <div className="priceTop">
              <h3 style={{ margin: 0 }}>Starter</h3>
              <span className="pill">شروع سریع</span>
            </div>
            <div className="price">199$</div>
            <ul className="features">
              <li>راه‌اندازی پایه + قوانین فروشگاه</li>
              <li>دموی Agent برای پاسخ به سوالات پرتکرار</li>
              <li>خروجی گزارش ساده (KPI پایه)</li>
              <li>پشتیبانی استاندارد</li>
            </ul>
            <Link className="ai-entry-btn priceBtn" href="/store">خرید / شروع</Link>
          </div>

          <div className="priceCard featured">
            <div className="priceTop">
              <h3 style={{ margin: 0 }}>Growth</h3>
              <span className="pill">پیشنهادی</span>
            </div>
            <div className="price">499$</div>
            <ul className="features">
              <li>Instagram DM + WhatsApp AI</li>
              <li>حالت شلوغی/آفلاین + هندآف به اپراتور</li>
              <li>اتصال کاتالوگ/محصول + جلوگیری از خطا</li>
              <li>داشبورد KPI و گزارش ROI</li>
            </ul>
            <Link className="ai-entry-btn priceBtn" href="/store">خرید / شروع پایلوت</Link>
          </div>

          <div className="priceCard">
            <div className="priceTop">
              <h3 style={{ margin: 0 }}>Enterprise</h3>
              <span className="pill">سفارشی</span>
            </div>
            <div className="price">تماس بگیرید</div>
            <ul className="features">
              <li>چند تیم + چند کانال</li>
              <li>Rule Engine پیشرفته + approvals</li>
              <li>اتصال CRM/داشبورد اختصاصی</li>
              <li>استقرار اختصاصی + امنیت/لاگ/ممیزی</li>
            </ul>
            <Link className="hero-btn-outline priceBtn" href="/#contact">درخواست پیشنهاد</Link>

            <div className="note">
              پرداخت ارزی: PayPal (در صورت پیکربندی) یا روش‌های قراردادی/Invoice.
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
