"use client";
import { useEffect, useRef } from "react";

export default function Services() {
  const ref = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const root = ref.current;
    if (!root) return;
    const els = Array.from(root.querySelectorAll(".reveal"));
    const io = new IntersectionObserver((entries) => {
      for (const e of entries) if (e.isIntersecting) e.target.classList.add("show");
    }, { threshold: 0.2 });
    els.forEach(el => io.observe(el));
    return () => io.disconnect();
  }, []);

  return (
    <section id="services" ref={ref} style={{ background: "var(--primary-dark)" }}>
      <div className="container">
        <div className="section-header reveal">
          <h2 className="section-title">
            <span className="highlight">خدمات</span> CoreDevs
          </h2>
          <p className="section-subtitle">
            ما برای آنلاین‌شاپ‌ها برنامه داریم: از پیام تا سفارش، از قوانین تا گزارش.
          </p>
        </div>

        <div className="grid4">
          <div className="card reveal">
            <div className="icon">🎯</div>
            <h3>Automation Strategy</h3>
            <p>نقشه راه: سناریوهای مهم (دایرکت/واتساپ)، KPIها، اولویت‌بندی برای نتیجه سریع.</p>
          </div>

          <div className="card reveal" style={{ transitionDelay: "80ms" }}>
            <div className="icon">⚙️</div>
            <h3>پیاده‌سازی و اتصال</h3>
            <p>اتصال کانال‌ها، ساخت قوانین، کاتالوگ، تست سناریوها، آموزش تیم.</p>
          </div>

          <div className="card reveal" style={{ transitionDelay: "160ms" }}>
            <div className="icon">🧠</div>
            <h3>AI Agent فروشنده</h3>
            <p>پاسخ‌گویی هوشمند، جمع‌آوری سفارش، پیشنهاد محصول، و انتقال به اپراتور.</p>
          </div>

          <div className="card reveal" style={{ transitionDelay: "240ms" }}>
            <div className="icon">📈</div>
            <h3>بهینه‌سازی مداوم</h3>
            <p>A/B تست پیام‌ها، بهبود سناریوها، گزارش هفتگی، افزایش تبدیل.</p>
          </div>
        </div>
      </div>
    </section>
  );
}
