export default function Footer() {
  return (
    <footer
      style={{
        background: "var(--primary-dark)",
        padding: "40px 20px",
        textAlign: "center",
        borderTop: "1px solid rgba(0,255,242,0.10)",
      }}
    >
      <div className="container">
        <div className="logo" style={{ marginBottom: 14, fontSize: 22 }}>
          CoreDevs
        </div>
        <p style={{ color: "rgba(234,234,240,0.65)", fontSize: 14, margin: 0 }}>
          © 2026 CoreDevs. آژانس اتوماسیون هوشمند.
        </p>
      </div>
    </footer>
  );
}
