"use client";
import { useMemo, useState } from "react";

export default function FAQ() {
  const items = useMemo(() => ([
    {
      q: "این سیستم دقیقاً چت‌باته یا فروشنده؟",
      a: "ما یک Agent فروش/پشتیبانی می‌سازیم: نیت را تشخیص می‌دهد، از روی کاتالوگ و قوانین جواب می‌دهد، اطلاعات سفارش را جمع می‌کند و در صورت ابهام به اپراتور منتقل می‌کند. یعنی خروجی‌محور است، نه صرفاً گفتگو."
    },
    {
      q: "اگر AI اشتباه جواب بده چی؟",
      a: "برای همین Guardrails داریم: پاسخ‌ها از روی دیتای محصول/قوانین ساخته می‌شود، قابلیت Approval (تایید قبل از ارسال) داریم، و در سناریوهای حساس (تخفیف/شرایط خاص) به انسان منتقل می‌کنیم."
    },
    {
      q: "برای فروشگاه اینستاگرامی که سایت نداره هم جواب می‌ده؟",
      a: "بله. کافی است دایرکت و واتساپ بیزینس شما وصل شود و کاتالوگ/قیمت‌ها را به‌صورت ساده (اکسل/گوگل‌شیت) به سیستم بدهیم."
    },
    {
      q: "در زمان شلوغی یا آفلاین دقیقاً چه می‌کند؟",
      a: "در حالت شلوغی، پیام‌ها را دسته‌بندی می‌کند و مسیر سریع سفارش را جلو می‌برد. در حالت آفلاین، سفارش را پیش‌نویس می‌کند تا بعداً با تایید اپراتور نهایی شود."
    },
    {
      q: "چطور ROI را گزارش می‌کنید؟",
      a: "KPIها مثل زمان پاسخ، پیام‌های بی‌پاسخ، لیدهای داغ، سفارش‌های ساخته‌شده و نرخ تبدیل قابل اندازه‌گیری است. گزارش‌ها می‌تواند در داشبورد یا Google Sheets تحویل شود."
    },
    {
      q: "زمان شروع چقدر است؟",
      a: "هدف پایلوت سریع است: اتصال کانال‌ها + قوانین + سناریوهای اصلی. سپس با داده واقعی بهینه‌سازی می‌کنیم."
    }
  ]), []);

  const [open, setOpen] = useState<number | null>(0);

  return (
    <section>
      <div className="container">
        <div className="section-header">
          <h2 className="section-title">
            سوالات <span className="highlight">پرتکرار</span>
          </h2>
          <p className="section-subtitle">
            این بخش برای کاهش تردید و افزایش اعتماد طراحی شده.
          </p>
        </div>

        <div className="faqGrid">
          {items.map((it, idx) => {
            const isOpen = open === idx;
            return (
              <div className="faqItem" key={it.q}>
                <button className="faqQ" onClick={() => setOpen(isOpen ? null : idx)}>
                  <span>{it.q}</span>
                  <span className="faqIcon">{isOpen ? "−" : "+"}</span>
                </button>
                {isOpen && <div className="faqA">{it.a}</div>}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
