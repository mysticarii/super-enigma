"use client";
import { useEffect, useRef } from "react";

type P = { x:number; y:number; vx:number; vy:number; r:number };

export default function LiveBackground() {
  const ref = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const c = ref.current;
    if (!c) return;
    const ctx = c.getContext("2d");
    if (!ctx) return;

    let w = 0, h = 0;
    const dpr = Math.max(1, Math.min(2, window.devicePixelRatio || 1));

    const resize = () => {
      w = c.width = Math.floor(window.innerWidth * dpr);
      h = c.height = Math.floor(Math.min(window.innerHeight, 900) * dpr);
      c.style.width = "100%";
      c.style.height = "100%";
    };
    resize();
    window.addEventListener("resize", resize);

    const reduceMotion = window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches;

    const n = 72;
    const ps: P[] = Array.from({ length: n }, () => ({
      x: Math.random() * w,
      y: Math.random() * h,
      vx: (Math.random() - 0.5) * 0.22 * dpr,
      vy: (Math.random() - 0.5) * 0.22 * dpr,
      r: (1 + Math.random() * 1.4) * dpr,
    }));

    let raf = 0;
    const maxDist = (160 * dpr) ** 2;

    const draw = () => {
      ctx.clearRect(0, 0, w, h);

      // subtle fade overlay (tiny trails)
      ctx.fillStyle = "rgba(5,7,15,0.20)";
      ctx.fillRect(0, 0, w, h);

      // particles
      for (const p of ps) {
        p.x += p.vx;
        p.y += p.vy;
        if (p.x < 0 || p.x > w) p.vx *= -1;
        if (p.y < 0 || p.y > h) p.vy *= -1;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = "rgba(0,255,242,0.20)";
        ctx.fill();
      }

      // links
      for (let i = 0; i < ps.length; i++) {
        for (let j = i + 1; j < ps.length; j++) {
          const a = ps[i], b = ps[j];
          const dx = a.x - b.x, dy = a.y - b.y;
          const d2 = dx*dx + dy*dy;
          if (d2 < maxDist) {
            const alpha = (1 - d2 / maxDist) * 0.12;
            ctx.strokeStyle = `rgba(209,110,255,${alpha})`;
            ctx.lineWidth = 1 * dpr;
            ctx.beginPath();
            ctx.moveTo(a.x, a.y);
            ctx.lineTo(b.x, b.y);
            ctx.stroke();
          }
        }
      }

      raf = requestAnimationFrame(draw);
    };

    if (!reduceMotion) draw();

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return (
    <canvas
      ref={ref}
      aria-hidden="true"
      style={{ position: "absolute", inset: 0, zIndex: 0, pointerEvents: "none" }}
    />
  );
}
