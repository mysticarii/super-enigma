"use client";

import { useEffect, useRef, useState } from "react";

declare global {
  interface Window {
    paypal?: any;
  }
}

export default function PayPalButton({
  order,
  onSuccess,
  onError,
}: {
  order: { productId: string; title: string; amountUsd: number; customer: any };
  onSuccess: () => void;
  onError: (msg: string) => void;
}) {
  const ref = useRef<HTMLDivElement | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const clientId = process.env.NEXT_PUBLIC_PAYPAL_CLIENT_ID;

    if (!clientId) {
      setReady(false);
      return;
    }

    const existing = document.querySelector<HTMLScriptElement>("script[data-paypal='sdk']");
    if (existing) {
      setReady(true);
      return;
    }

    const s = document.createElement("script");
    s.src = `https://www.paypal.com/sdk/js?client-id=${clientId}&currency=USD&intent=capture`;
    s.async = true;
    (s as any).dataset.paypal = "sdk";
    s.onload = () => setReady(true);
    s.onerror = () => onError("لود PayPal SDK ناموفق بود");
    document.body.appendChild(s);
  }, [onError]);

  useEffect(() => {
    if (!ready) return;
    if (!ref.current) return;
    if (!window.paypal) return;

    ref.current.innerHTML = "";

    window.paypal
      .Buttons({
        style: { layout: "vertical", shape: "rect" },
        createOrder: async () => {
          const res = await fetch("/api/paypal/create-order", {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify(order),
          });
          const data = await res.json();
          if (!res.ok) throw new Error(data?.error || "Create order failed");
          return data.id; // orderID
        },
        onApprove: async (data: any) => {
          const res = await fetch("/api/paypal/capture-order", {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify({ orderID: data.orderID }),
          });
          const out = await res.json();
          if (!res.ok) {
            onError(out?.error || "Capture failed");
            return;
          }
          onSuccess();
        },
        onError: (err: any) => onError(err?.message || "PayPal error"),
      })
      .render(ref.current);
  }, [ready, order, onSuccess, onError]);

  if (!process.env.NEXT_PUBLIC_PAYPAL_CLIENT_ID) {
    return <div className="payDisabled">PayPal پیکربندی نشده است. (Client ID لازم است)</div>;
  }

  return <div ref={ref} />;
}
