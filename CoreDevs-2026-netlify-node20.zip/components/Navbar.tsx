"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useMemo, useState } from "react";

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();

  useEffect(() => {
    const onResize = () => {
      if (window.innerWidth > 860) setOpen(false);
    };
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  const items = useMemo(() => ([
    { href: "/#services", label: "خدمات" },
    { href: "/#architecture", label: "معماری" },
    { href: "/#data", label: "دیتا" },
    { href: "/store", label: "خرید" },
    { href: "/hosting", label: "هاست و دامنه" },
    { href: "/ai", label: "هوش مصنوعی", badge: "AI" },
    { href: "/#contact", label: "تماس" },
  ]), []);

  return (
    <header>
      <nav>
        <div className="container navRow">
          <Link href="/" className="logo glitch-effect" data-text="CoreDevs">
            CoreDevs
          </Link>

          <button
            className={`mobile-menu-btn ${open ? "open" : ""}`}
            onClick={() => setOpen((v) => !v)}
            aria-label="Toggle menu"
            aria-expanded={open}
          >
            <span />
            <span />
            <span />
          </button>

          <ul className={`nav-links ${open ? "show" : ""}`} onClick={() => setOpen(false)}>
            {items.map((it) => {
              const active =
                it.href === "/ai" ? pathname === "/ai"
                : it.href === "/store" ? pathname === "/store"
                : it.href === "/hosting" ? pathname === "/hosting"
                : false;

              return (
                <li key={it.href}>
                  <Link href={it.href} className={active ? "navActive" : ""}>
                    {it.label}
                    {it.badge && <span className="navBadge">{it.badge}</span>}
                  </Link>
                </li>
              );
            })}

            <li className="navCtaWrap">
              <Link href="/onboarding?product=whatsapp-instagram-ai" className="navCta">
                رزرو دمو / شروع پایلوت
              </Link>
            </li>
          </ul>
        </div>
      </nav>
    </header>
  );
}
