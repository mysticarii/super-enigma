"use client";
import { useEffect, useRef } from "react";
import Chart from "chart.js/auto";

export default function GrowthChart() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const chartRef = useRef<Chart | null>(null);

  useEffect(() => {
    const c = canvasRef.current;
    if (!c) return;

    const labels = Array.from({ length: 12 }, (_, i) => `هفته ${i + 1}`);

    const manual = [10, 10, 11, 12, 11, 12, 13, 13, 14, 14, 15, 16];
    const withAI = [10, 12, 16, 22, 30, 39, 50, 64, 82, 104, 130, 160];

    chartRef.current = new Chart(c, {
      type: "line",
      data: {
        labels,
        datasets: [
          { label: "بدون اتوماسیون", data: manual, tension: 0.35 },
          { label: "با AI فروشنده", data: withAI, tension: 0.35 },
        ],
      },
      options: {
        responsive: true,
        animation: { duration: 650 },
        plugins: {
          legend: { labels: { color: "rgba(234,234,240,0.85)" } },
          tooltip: {
            titleColor: "rgba(234,234,240,0.95)",
            bodyColor: "rgba(234,234,240,0.85)",
          },
        },
        scales: {
          x: {
            ticks: { color: "rgba(234,234,240,0.65)" },
            grid: { color: "rgba(255,255,255,0.06)" },
          },
          y: {
            ticks: { color: "rgba(234,234,240,0.65)" },
            grid: { color: "rgba(255,255,255,0.06)" },
          },
        },
      },
    });

    // simulate "live streaming"
    const timer = setInterval(() => {
      const ch = chartRef.current;
      if (!ch) return;

      ch.data.labels = [...(ch.data.labels || []).slice(1), "اکنون"];

      ch.data.datasets.forEach((ds, idx) => {
        const arr = (ds.data as number[]);
        const last = arr[arr.length - 1] ?? 0;

        const jitter = idx === 0
          ? Math.max(0, Math.round(last + (Math.random() * 2 - 0.5)))
          : Math.max(0, Math.round(last + (Math.random() * 9 + 1)));

        ds.data = [...arr.slice(1), jitter];
      });

      ch.update();
    }, 1600);

    return () => {
      clearInterval(timer);
      chartRef.current?.destroy();
      chartRef.current = null;
    };
  }, []);

  return (
    <section id="data">
      <div className="container">
        <div className="section-header">
          <h2 className="section-title">
            <span className="highlight">ROI</span> قابل اندازه‌گیری
          </h2>
          <p className="section-subtitle">
            هدف ما «افکت» نیست؛ هدف نتیجه است: کاهش پیام‌های بی‌پاسخ، افزایش تبدیل، و گزارش دقیق (Live Demo).
          </p>
        </div>

        <div className="chart-container">
          <canvas ref={canvasRef} />
          <div className="chart-overlay">
            <div className="stat-badge">
              <span className="pulse-dot"></span>
              زنده
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
