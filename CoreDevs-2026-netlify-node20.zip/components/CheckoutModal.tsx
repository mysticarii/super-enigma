"use client";

import { useEffect, useMemo, useState } from "react";
import PayPalButton from "./PayPalButton";

export type Product = {
  id: string;
  title: string;
  priceUsd: number;
  desc: string;
  features: string[];
};

export default function CheckoutModal({
  open,
  onClose,
  product,
}: {
  open: boolean;
  onClose: () => void;
  product: Product | null;
}) {
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [customer, setCustomer] = useState({ name: "", email: "", note: "" });
  const [result, setResult] = useState<{ ok: boolean; msg: string } | null>(null);

  useEffect(() => {
    if (!open) {
      setStep(1);
      setCustomer({ name: "", email: "", note: "" });
      setResult(null);
    }
  }, [open]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && open && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  const order = useMemo(() => {
    if (!product) return null;
    return {
      productId: product.id,
      title: product.title,
      amountUsd: product.priceUsd,
      customer,
    };
  }, [product, customer]);

  if (!open || !product) return null;

  return (
    <div className="modalBackdrop" role="dialog" aria-modal="true">
      <div className="modalCard">
        <div className="modalTop">
          <div>
            <div className="modalTitle">خرید: {product.title}</div>
            <div className="modalSub">پرداخت ارزی • بعد از خرید وارد Onboarding اتصال می‌شوید</div>
          </div>
          <button className="modalClose" onClick={onClose} aria-label="Close">
            ✕
          </button>
        </div>

        <div className="modalBody">
          <div className="modalSteps">
            <div className={`pillStep ${step === 1 ? "on" : ""}`}>۱) اطلاعات</div>
            <div className={`pillStep ${step === 2 ? "on" : ""}`}>۲) پرداخت</div>
            <div className={`pillStep ${step === 3 ? "on" : ""}`}>۳) تایید</div>
          </div>

          {step === 1 && (
            <div className="modalPanel">
              <div className="formRow">
                <input
                  value={customer.name}
                  onChange={(e) => setCustomer((v) => ({ ...v, name: e.target.value }))}
                  placeholder="نام"
                  required
                />
                <input
                  value={customer.email}
                  onChange={(e) => setCustomer((v) => ({ ...v, email: e.target.value }))}
                  placeholder="ایمیل"
                  type="email"
                  required
                />
              </div>

              <div style={{ marginTop: 10 }}>
                <textarea
                  value={customer.note}
                  onChange={(e) => setCustomer((v) => ({ ...v, note: e.target.value }))}
                  placeholder="یادداشت (اختیاری): اینستاگرام‌شاپ هستید؟ حجم پیام‌ها؟"
                />
              </div>

              <div className="modalBottom">
                <button className="hero-btn-outline" onClick={onClose}>
                  فعلاً نه
                </button>
                <button
                  className="ai-entry-btn"
                  onClick={() => setStep(2)}
                  disabled={!customer.name.trim() || !customer.email.trim()}
                >
                  ادامه پرداخت
                </button>
              </div>

              <div className="note">
                هدف ما پایلوت سریع است. بعد از ثبت، وارد مرحله اتصال/قوانین می‌شوید.
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="modalPanel">
              <div className="checkoutSummary">
                <div className="sumRow">
                  <span>محصول</span>
                  <span>{product.title}</span>
                </div>
                <div className="sumRow">
                  <span>قیمت</span>
                  <span>${product.priceUsd}</span>
                </div>
                <div className="sumRow">
                  <span>ایمیل</span>
                  <span>{customer.email}</span>
                </div>
              </div>

              <div className="payBox">
                <div className="payTitle">پرداخت با PayPal (اختیاری)</div>
                <div className="paySub">
                  برای فعال شدن دکمه‌ها، متغیر محیطی <code>NEXT_PUBLIC_PAYPAL_CLIENT_ID</code> را تنظیم کنید.
                </div>

                <PayPalButton
                  order={order!}
                  onSuccess={() => {
                    setResult({ ok: true, msg: "پرداخت با موفقیت انجام شد ✅" });
                    setStep(3);
                  }}
                  onError={(m) => setResult({ ok: false, msg: m })}
                />

                {result && !result.ok && <div className="note" style={{ marginTop: 10 }}>❌ {result.msg}</div>}
              </div>

              <div className="modalBottom">
                <button className="hero-btn-outline" onClick={() => setStep(1)}>
                  بازگشت
                </button>
                <button className="ai-entry-btn" onClick={() => setStep(3)}>
                  پرداخت را بعداً انجام می‌دهم
                </button>
              </div>

              <div className="note">
                بعد از ثبت، تیم CoreDevs برای اتصال دایرکت/واتساپ و تعریف قوانین با شما هماهنگ می‌کند.
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="modalPanel">
              <div className="successBox">
                <div className="successTitle">درخواست شما ثبت شد ✅</div>
                <div className="successSub">قدم بعدی: ورود به مرحله اتصال و قوانین (Onboarding)</div>
              </div>

              <div className="modalBottom">
                <button className="hero-btn-outline" onClick={onClose}>
                  بستن
                </button>
                <a className="ai-entry-btn" href={`/onboarding?product=${encodeURIComponent(product.id)}`}>
                  رفتن به مرحله اتصال
                </a>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
