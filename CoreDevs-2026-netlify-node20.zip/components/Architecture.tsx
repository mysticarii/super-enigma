"use client";
import { useEffect, useRef } from "react";

export default function Architecture() {
  const ref = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const root = ref.current;
    if (!root) return;
    const els = Array.from(root.querySelectorAll(".reveal"));
    const io = new IntersectionObserver((entries) => {
      for (const e of entries) if (e.isIntersecting) e.target.classList.add("show");
    }, { threshold: 0.2 });
    els.forEach(el => io.observe(el));
    return () => io.disconnect();
  }, []);

  return (
    <section id="architecture" ref={ref} style={{ background: "var(--primary-dark)" }}>
      <div className="container">
        <div className="section-header reveal">
          <h2 className="section-title">
            <span className="highlight">معماری</span> Agent محور
          </h2>
          <p className="section-subtitle">
            ما «چت‌بات ساده» نمی‌فروشیم؛ یک سیستم فروش/پشتیبانی می‌سازیم که ورودی/خروجی، قوانین و کنترل دارد.
          </p>
        </div>

        <div className="grid4">
          <div className="card reveal">
            <div className="icon">🧠</div>
            <h3>Intent + Routing</h3>
            <p>فهم نیت: قیمت/موجودی، ثبت سفارش، پیگیری، مرجوعی… و هدایت به سناریوی درست.</p>
          </div>

          <div className="card reveal" style={{transitionDelay:"80ms"}}>
            <div className="icon">📚</div>
            <h3>Catalog + Policies</h3>
            <p>پاسخ بر اساس کاتالوگ محصول و قوانین فروشگاه (RAG) تا خطا/توهم کم شود.</p>
          </div>

          <div className="card reveal" style={{transitionDelay:"160ms"}}>
            <div className="icon">🧾</div>
            <h3>Order Draft</h3>
            <p>جمع‌آوری اطلاعات سفارش، ساخت پیش‌فاکتور، ارسال لینک پرداخت/تایید.</p>
          </div>

          <div className="card reveal" style={{transitionDelay:"240ms"}}>
            <div className="icon">🛡️</div>
            <h3>Guardrails + Handoff</h3>
            <p>حالت‌های کنترل: تایید قبل از ارسال، محدودیت پیشنهاد تخفیف، انتقال به اپراتور.</p>
          </div>
        </div>
      </div>
    </section>
  );
}
