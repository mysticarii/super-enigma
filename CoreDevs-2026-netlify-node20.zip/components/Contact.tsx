"use client";
import { useState } from "react";

export default function Contact() {
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setMsg(null);
    setLoading(true);

    const fd = new FormData(e.currentTarget);
    const payload = {
      name: String(fd.get("name") || ""),
      email: String(fd.get("email") || ""),
      instagram: String(fd.get("instagram") || ""),
      whatsapp: String(fd.get("whatsapp") || ""),
      message: String(fd.get("message") || ""),
    };

    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || "خطا در ارسال");

      setMsg("✅ پیام شما ثبت شد. برای شروع پایلوت با شما هماهنگ می‌کنیم.");
      (e.target as HTMLFormElement).reset();
    } catch (err: any) {
      setMsg(`❌ ${err?.message || "مشکلی پیش آمد"}`);
    } finally {
      setLoading(false);
    }
  }

  return (
    <section className="contact-section" id="contact">
      <div className="container">
        <div className="section-header">
          <h2 className="section-title">
            <span className="highlight">شروع</span> همکاری
          </h2>
          <p className="section-subtitle">14 روز پایلوت. شفاف، قابل کنترل، قابل گزارش.</p>
        </div>

        <div className="contactGrid">
          <form className="form" onSubmit={onSubmit}>
            <div className="formRow">
              <input name="name" placeholder="نام" required />
              <input name="email" placeholder="ایمیل" type="email" required />
            </div>

            <div className="formRow" style={{marginTop:10}}>
              <input name="instagram" placeholder="آیدی اینستاگرام (اختیاری)" />
              <input name="whatsapp" placeholder="واتساپ بیزینس (اختیاری)" />
            </div>

            <div style={{ marginTop: 10 }}>
              <textarea
                name="message"
                placeholder="چی رو می‌خوای اتوماسیون کنیم؟ (دایرکت، واتساپ، ثبت سفارش، پیگیری…)"
                required
              />
            </div>

            <div style={{ marginTop: 12 }}>
              <button className="ai-entry-btn" type="submit" disabled={loading} style={{ width: "100%", justifyContent:"center" }}>
                {loading ? "در حال ارسال..." : "ارسال درخواست"}
              </button>
              {msg && <div className="note" style={{ marginTop: 10 }}>{msg}</div>}
              <div className="note">
                هدف ما اینه که سریع وارد پایلوت بشیم و با داده واقعی بهینه کنیم.
              </div>
            </div>
          </form>

          <div>
            <div className="card">
              <div className="icon">📧</div>
              <h3>ایمیل</h3>
              <p>hello@coredevs.io</p>
            </div>

            <div className="card" style={{ marginTop: 14 }}>
              <div className="icon">💬</div>
              <h3>تلگرام</h3>
              <p>@CoreDevsSupport</p>
            </div>

            <div className="card" style={{ marginTop: 14 }}>
              <div className="icon">📷</div>
              <h3>اینستاگرام</h3>
              <p>@CoreDevsAgency</p>
            </div>

            <div className="card" style={{ marginTop: 14 }}>
              <div className="icon">📞</div>
              <h3>تماس</h3>
              <p>+98 XXX XXX XXXX</p>
            </div>

            <div style={{ marginTop: 14 }}>
              <a className="ai-entry-btn" href="/onboarding?product=whatsapp-instagram-ai" style={{ width: "100%", justifyContent: "center" }}>
                <span className="ai-icon">🚀</span>
                شروع پایلوت
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
