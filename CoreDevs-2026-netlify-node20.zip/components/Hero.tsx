"use client";
import { useEffect, useMemo, useState } from "react";
import LiveBackground from "./LiveBackground";

export default function Hero() {
  const phrases = useMemo(() => ([
    "دایرکت اینستاگرام و واتساپِ آنلاین‌شاپت رو به AI فروشنده وصل کن.",
    "زمان شلوغی یا آفلاین: جمع‌آوری سفارش + پاسخ با قوانین فروشگاه.",
    "همه چیز قابل کنترل و گزارشه: هندآف به اپراتور + لاگ + KPI."
  ]), []);

  const [text, setText] = useState("");
  const [pi, setPi] = useState(0);
  const [typing, setTyping] = useState(true);

  useEffect(() => {
    let t: any;
    const full = phrases[pi] || "";
    if (typing) {
      t = setTimeout(() => {
        setText(full.slice(0, text.length + 1));
        if (text.length + 1 >= full.length) setTyping(false);
      }, 26);
    } else {
      t = setTimeout(() => {
        if (text.length > 0) setText(text.slice(0, -1));
        else {
          setPi((v) => (v + 1) % phrases.length);
          setTyping(true);
        }
      }, 14);
    }
    return () => clearTimeout(t);
  }, [text, typing, pi, phrases]);

  return (
    <section className="hero">
      <div className="container">
        <div className="heroShell">
          <LiveBackground />
          <div className="cyberGrid" />
          <div className="heroVignette" />

          <div className="heroInner">
            <div className="glitch-text">
              <span className="code-bracket">&lt;</span>
              CoreDevs
              <span className="code-bracket">&gt;</span>
            </div>

            <div className="npuWrap" aria-hidden="true">
              <div className="npuLoader">
                <div className="orbit o1" />
                <div className="orbit o2" />
                <div className="orbit o3" />
                <div className="npuCore">
                  <div className="pulseDot" />
                </div>
              </div>
            </div>

            <h1>
              <span className="highlight">اتوماسیون هوشمند</span> برای فروشگاه‌های اینستاگرامی
            </h1>

            <div className="typing-sub">
              {text}
              <span style={{opacity:0.7}}>▍</span>
            </div>

            <div className="heroActions">
              <a className="ai-entry-btn" href="/ai">
                <span className="ai-icon">🧠</span>
                AI Lab + دمو واتساپ/دایرکت
              </a>
              <a className="hero-btn-outline" href="/store">خرید / شروع پایلوت</a>
            </div>

            <div style={{marginTop:14, display:"flex", justifyContent:"center", gap:10, flexWrap:"wrap"}}>
              <span style={{
                padding:"10px 12px",
                borderRadius:999,
                background:"rgba(0,0,0,0.35)",
                outline:"1px solid rgba(255,255,255,0.10)",
                color:"rgba(234,234,240,0.78)",
                fontWeight:900
              }}>✅ کنترل قوانین</span>
              <span style={{
                padding:"10px 12px",
                borderRadius:999,
                background:"rgba(0,0,0,0.35)",
                outline:"1px solid rgba(255,255,255,0.10)",
                color:"rgba(234,234,240,0.78)",
                fontWeight:900
              }}>✅ انتقال به اپراتور</span>
              <span style={{
                padding:"10px 12px",
                borderRadius:999,
                background:"rgba(0,0,0,0.35)",
                outline:"1px solid rgba(255,255,255,0.10)",
                color:"rgba(234,234,240,0.78)",
                fontWeight:900
              }}>✅ گزارش KPI/ROI</span>
              <span style={{
                padding:"10px 12px",
                borderRadius:999,
                background:"rgba(0,0,0,0.35)",
                outline:"1px solid rgba(255,255,255,0.10)",
                color:"rgba(234,234,240,0.78)",
                fontWeight:900
              }}>✅ 14 روز پایلوت</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
