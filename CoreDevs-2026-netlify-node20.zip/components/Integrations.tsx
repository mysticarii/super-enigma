"use client";
import { useEffect, useRef } from "react";

const items = [
  { icon: "📩", title: "Instagram DM", desc: "اتصال دایرکت برای پاسخگویی، فیلتر لید، و هندآف به اپراتور." },
  { icon: "💬", title: "WhatsApp Business", desc: "فروشنده AI با قوانین: موجودی/قیمت، جمع‌آوری سفارش، پیگیری." },
  { icon: "📦", title: "کاتالوگ/محصول", desc: "از فایل/اکسل/سیستم فروشگاهی: محصول، قیمت، موجودی، ویژگی‌ها." },
  { icon: "🧾", title: "پرداخت و سفارش", desc: "پیش‌فاکتور، لینک پرداخت، ثبت سفارش (با تایید یا Rule)." },
  { icon: "📊", title: "Google Sheets / Dashboard", desc: "گزارش KPI، پیام‌های مهم، لیدهای داغ، خروجی قابل اشتراک." },
  { icon: "🧑‍💻", title: "Human Handoff", desc: "وقتی ابهام/نارضایتی هست، انتقال به اپراتور با خلاصه مکالمه." },
  { icon: "🛡️", title: "Guardrails", desc: "قوانین فروشگاه + محدودیت‌های پاسخ + جلوگیری از وعده اشتباه." },
  { icon: "⚙️", title: "API اختصاصی", desc: "اگر ابزار شما خاص است، API/اتصال اختصاصی می‌زنیم." },
];

export default function Integrations() {
  const ref = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const root = ref.current;
    if (!root) return;
    const els = Array.from(root.querySelectorAll(".reveal"));
    const io = new IntersectionObserver((entries) => {
      for (const e of entries) if (e.isIntersecting) e.target.classList.add("show");
    }, { threshold: 0.2 });
    els.forEach(el => io.observe(el));
    return () => io.disconnect();
  }, []);

  return (
    <section ref={ref}>
      <div className="container">
        <div className="section-header reveal">
          <h2 className="section-title">
            <span className="highlight">اتصال‌ها</span> برای آنلاین‌شاپ‌های اینستاگرامی
          </h2>
          <p className="section-subtitle">
            این بخش عمداً قبل از قیمت‌گذاری می‌آید: چون بزرگ‌ترین ترس مشتری «وصل می‌شه یا نه؟» است.
          </p>
        </div>

        <div className="grid4">
          {items.map((x, i) => (
            <div className="card reveal" key={x.title} style={{transitionDelay: `${(i%4)*70}ms`}}>
              <div className="icon">{x.icon}</div>
              <h3>{x.title}</h3>
              <p>{x.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
