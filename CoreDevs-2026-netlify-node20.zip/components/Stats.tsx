"use client";
import { useEffect, useMemo, useRef, useState } from "react";

function animateNumber(from: number, to: number, ms: number, onUpdate: (v:number)=>void) {
  const start = performance.now();
  function tick(t: number) {
    const p = Math.min(1, (t - start) / ms);
    const eased = 1 - Math.pow(1 - p, 3);
    onUpdate(Math.round(from + (to - from) * eased));
    if (p < 1) requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
}

export default function Stats() {
  const items = useMemo(() => ([
    { target: 62, label: "% کاهش زمان پاسخ", delay: 0 },
    { target: 31, label: "% کاهش پیام‌های بی‌پاسخ", delay: 90 },
    { target: 19, label: "% افزایش تبدیل (نمونه)", delay: 180 },
    { target: 24, label: "/ 7 پاسخگویی", delay: 270 },
  ]), []);

  const ref = useRef<HTMLDivElement | null>(null);
  const [values, setValues] = useState(items.map(() => 0));
  const [done, setDone] = useState(false);

  useEffect(() => {
    const root = ref.current;
    if (!root) return;
    const revealEls = Array.from(root.querySelectorAll<HTMLElement>(".reveal"));

    const io = new IntersectionObserver((entries) => {
      for (const e of entries) if (e.isIntersecting) e.target.classList.add("show");
    }, { threshold: 0.2 });

    revealEls.forEach(el => io.observe(el));
    return () => io.disconnect();
  }, []);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const io = new IntersectionObserver((entries) => {
      if (entries[0]?.isIntersecting && !done) {
        setDone(true);
        items.forEach((it, idx) => {
          setTimeout(() => {
            animateNumber(0, it.target, 1100, (v) => {
              setValues(prev => {
                const copy = [...prev];
                copy[idx] = v;
                return copy;
              });
            });
          }, it.delay);
        });
      }
    }, { threshold: 0.35 });

    io.observe(el);
    return () => io.disconnect();
  }, [done, items]);

  return (
    <section className="stats-section" ref={ref}>
      <div className="container">
        <div className="section-header reveal">
          <h2 className="section-title">
            <span className="highlight">نتیجه</span> قبل از پیچیدگی
          </h2>
          <p className="section-subtitle">
            عددها نمونه‌اند تا حس محصول را منتقل کنیم؛ در پروژه واقعی، KPIها از روی دیتای پیام‌ها و فروش اندازه‌گیری می‌شوند.
          </p>
        </div>

        <div className="stats-grid">
          {items.map((it, i) => (
            <div className="stat-card reveal" key={it.label} style={{transitionDelay: `${i * 80}ms`}}>
              <span className="stat-number">{values[i]}</span>
              <span className="stat-label">{it.label}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
