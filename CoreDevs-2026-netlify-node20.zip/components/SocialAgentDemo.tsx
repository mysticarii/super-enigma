"use client";

import { useMemo, useState } from "react";

type Mode = "normal" | "busy" | "offline";
type Channel = "whatsapp" | "instagram";

export default function SocialAgentDemo() {
  const [channel, setChannel] = useState<Channel>("whatsapp");
  const [mode, setMode] = useState<Mode>("normal");
  const [step, setStep] = useState(0);

  const flows = useMemo(() => ({
    whatsapp: {
      normal: [
        { from: "user", text: "سلام، این کفش سایز ۴۲ موجوده؟" },
        { from: "ai", text: "سلام 🌿 بله. مدل «Runner X» سایز ۴۲ موجوده. رنگ مشکی/سفید هم داریم. رنگ مدنظر شما کدومه؟" },
        { from: "user", text: "مشکی. قیمت و ارسال؟" },
        { from: "ai", text: "قیمت: 69$. ارسال: 2–4 روز کاری. اگر شهر رو بگید هزینه ارسال رو دقیق می‌گم. دوست دارید همینجا سفارش رو ثبت کنم؟" },
      ],
      busy: [
        { from: "user", text: "سلام، موجودی دارید؟" },
        { from: "ai", text: "سلام 👋 الان زمان شلوغیه. نام محصول + سایز/رنگ رو بفرستید تا موجودی رو فوری چک کنم." },
        { from: "user", text: "Runner X سایز ۴۲ مشکی" },
        { from: "ai", text: "✅ موجوده. برای ثبت سریع سفارش: نام گیرنده + شهر + آدرس کوتاه رو بفرستید. (در صورت نیاز اپراتور ادامه می‌دهد.)" },
      ],
      offline: [
        { from: "user", text: "سلام، می‌خوام سفارش بدم" },
        { from: "ai", text: "سلام 🌙 الان تیم آفلاینه، ولی من سفارش رو «پیش‌نویس» می‌کنم تا اولین فرصت تایید شود. محصول/سایز/رنگ رو بفرستید." },
        { from: "user", text: "کفش Runner X سایز ۴۲ مشکی" },
        { from: "ai", text: "عالی. لطفاً شهر + نام گیرنده رو بفرستید. بعد از ثبت پیش‌نویس، لینک پرداخت/تایید برای شما ارسال می‌شه." },
      ],
    },
    instagram: {
      normal: [
        { from: "user", text: "سلام، قیمت این مانتو چنده؟" },
        { from: "ai", text: "سلام 🌸 قیمت مانتو «Luna» الان 48$ هست. دوست دارید سایز (S/M/L) رو بگید تا موجودی رو دقیق چک کنم؟" },
        { from: "user", text: "سایز M رنگ کرم" },
        { from: "ai", text: "✅ موجوده. برای ثبت سفارش سریع: نام + شهر رو بفرستید تا لینک پرداخت/تایید رو ارسال کنم." },
      ],
      busy: [
        { from: "user", text: "سلام، ارسال دارید؟" },
        { from: "ai", text: "سلام 👋 الان حجم پیام‌ها بالاست. لطفاً شهر رو بفرستید تا زمان/هزینه ارسال رو دقیق بگم." },
        { from: "user", text: "تهران" },
        { from: "ai", text: "ارسال تهران: 1–2 روز کاری. اگر محصول/سایز رو بگید سفارش رو همینجا پیش‌نویس می‌کنم." },
      ],
      offline: [
        { from: "user", text: "سلام، کی موجود میشه؟" },
        { from: "ai", text: "سلام 🌙 الان تیم آفلاینه. من درخواست شما رو ثبت می‌کنم و اگر محصول موجود شد خبر می‌دم. اسم محصول/سایز رو بفرستید." },
        { from: "user", text: "مانتو Luna سایز M" },
        { from: "ai", text: "ثبت شد ✅ به‌محض موجود شدن پیام می‌دیم. اگر رنگ جایگزین هم مدنظر دارید بگید." },
      ],
    }
  }), []);

  const msgs = flows[channel][mode].slice(0, step + 1);

  function reset(newChannel?: Channel, newMode?: Mode) {
    if (newChannel) setChannel(newChannel);
    if (newMode) setMode(newMode);
    setStep(0);
  }

  return (
    <div className="waDemo">
      <div className="waHeader">
        <div>
          <div className="waTitle">دموی AI فروشنده برای دایرکت + واتساپ</div>
          <div className="waSub">
            ۳ حالت کلیدی: نرمال / شلوغی / آفلاین — با قوانین و کمترین خطا
          </div>

          <div className="waChannelRow" aria-label="Channel">
            <button className={`chip ${channel==="whatsapp" ? "active" : ""}`} onClick={() => reset("whatsapp", mode)}>
              WhatsApp
            </button>
            <button className={`chip ${channel==="instagram" ? "active" : ""}`} onClick={() => reset("instagram", mode)}>
              Instagram DM
            </button>
          </div>
        </div>

        <div className="waModes" aria-label="Mode">
          <button className={mode==="normal" ? "active" : ""} onClick={() => reset(channel, "normal")}>نرمال</button>
          <button className={mode==="busy" ? "active" : ""} onClick={() => reset(channel, "busy")}>شلوغی</button>
          <button className={mode==="offline" ? "active" : ""} onClick={() => reset(channel, "offline")}>آفلاین</button>
        </div>
      </div>

      <div className="waChat">
        {msgs.map((m, i) => (
          <div key={i} className={`waMsg ${m.from === "ai" ? "ai" : "user"}`}>
            <div className="bubble">{m.text}</div>
          </div>
        ))}
      </div>

      <div className="waFooter">
        <button
          className="ai-entry-btn"
          onClick={() => setStep((s) => Math.min(flows[channel][mode].length - 1, s + 1))}
          disabled={step >= flows[channel][mode].length - 1}
        >
          پیام بعدی (Demo)
        </button>

        <div className="waRules">
          <div className="waRulesTitle">Guardrails (کنترل خطا)</div>
          <ul>
            <li>پاسخ فقط از روی «کاتالوگ + قوانین فروشگاه» (RAG)</li>
            <li>قیمت/موجودی از روی دیتای واقعی چک می‌شود</li>
            <li>تخفیف/پرداخت فقط با Rule یا تایید</li>
            <li>ابهام/نارضایتی → انتقال به اپراتور + خلاصه مکالمه</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
