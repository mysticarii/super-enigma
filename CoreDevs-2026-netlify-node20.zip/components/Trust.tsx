"use client";
import { useEffect, useRef } from "react";

const items = [
  {
    icon: "🔎",
    title: "شفافیت کامل",
    desc: "هر گفتگو لاگ می‌شود. می‌دانید AI چه گفت، چرا گفت، و نتیجه چه شد."
  },
  {
    icon: "🧯",
    title: "کنترل ریسک",
    desc: "حالت تایید قبل از ارسال (Approval) + محدودیت تخفیف/وعده + پاسخ بر اساس دیتا."
  },
  {
    icon: "🧑‍💻",
    title: "هندآف به انسان",
    desc: "اگر ابهام یا نارضایتی باشد، پیام به اپراتور منتقل می‌شود + خلاصه آماده."
  },
  {
    icon: "🧱",
    title: "قوانین فروشگاه",
    desc: "قیمت، ارسال، مرجوعی، موجودی، شرایط… به‌صورت policy تعریف می‌شود؛ نه حدس."
  },
  {
    icon: "📈",
    title: "KPI و ROI",
    desc: "زمان پاسخ، نرخ تبدیل، لید داغ، سفارش‌های ساخته‌شده، پیام‌های حل‌شده…"
  },
  {
    icon: "🛡️",
    title: "حریم خصوصی",
    desc: "حداقل دسترسی لازم. داده‌ها هدفمند ذخیره می‌شوند. در صورت نیاز: حذف/ماسک اطلاعات."
  },
  {
    icon: "⚙️",
    title: "قابل توسعه",
    desc: "امروز واتساپ/دایرکت، فردا CRM/سایت/اتوماسیون‌های پیشرفته‌تر."
  },
  {
    icon: "🧩",
    title: "تحویل استاندارد",
    desc: "چک‌لیست تحویل، تست سناریوها، آموزش تیم، و پشتیبانی بعد از اجرا."
  },
];

export default function Trust() {
  const ref = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const root = ref.current;
    if (!root) return;
    const els = Array.from(root.querySelectorAll(".reveal"));
    const io = new IntersectionObserver((entries) => {
      for (const e of entries) if (e.isIntersecting) e.target.classList.add("show");
    }, { threshold: 0.2 });
    els.forEach(el => io.observe(el));
    return () => io.disconnect();
  }, []);

  return (
    <section ref={ref}>
      <div className="container">
        <div className="section-header reveal">
          <h2 className="section-title">
            چرا می‌تونید با <span className="highlight">خیال راحت</span> بسپارید؟
          </h2>
          <p className="section-subtitle">
            مشتری آنلاین‌شاپ باید حس کند «کنترل دارم»؛ اینجا دقیقاً همان‌جاست که اعتماد ساخته می‌شود.
          </p>
        </div>

        <div className="grid4">
          {items.map((x, i) => (
            <div className="card reveal" key={x.title} style={{transitionDelay: `${(i%4)*70}ms`}}>
              <div className="icon">{x.icon}</div>
              <h3>{x.title}</h3>
              <p>{x.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
