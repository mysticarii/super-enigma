"use client";
import { useEffect, useState } from "react";

export default function ScrollProgress() {
  const [p, setP] = useState(0);

  useEffect(() => {
    const onScroll = () => {
      const h = document.documentElement;
      const total = Math.max(1, h.scrollHeight - h.clientHeight);
      setP(Math.min(1, Math.max(0, h.scrollTop / total)));
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div className="scrollProgress" aria-hidden="true">
      <div className="scrollProgressBar" style={{ transform: `scaleX(${p})` }} />
    </div>
  );
}
