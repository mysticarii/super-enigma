# CoreDevs 2026 (Instagram + WhatsApp AI) — Next.js Project

این پروژه یک وب‌سایت محصولی/آژانسی 2026 برای **CoreDevs** است که روی نیاز اصلی بازار ایران تمرکز دارد:
- فروشگاه‌های اینستاگرامی
- واتساپ بیزینس
- فروش/پشتیبانی با **AI Agent** + کنترل قوانین (Guardrails)
- خرید سرویس‌ها + Onboarding + بخش هاست و دامنه
- تب **AI Lab** با گرافیک WebGL/Three.js و دموی چت

> نکته: پرداخت PayPal در این پروژه **اختیاری** است و فقط در صورتی فعال می‌شود که Client ID و Secret را در `.env.local` تنظیم کنید.
> از مسیرهای رسمی و سازگار با قوانین/شرایط سرویس‌دهنده استفاده کنید.

---

## اجرای پروژه (محلی)

### 1) نصب
```bash
npm install
```

### 2) اجرای Dev
```bash
npm run dev
```

### 3) Build و اجرای Production
```bash
npm run build
npm run start
```

---

## مسیرهای مهم
- `/` صفحه اصلی (Landing)
- `/ai` تب هوش مصنوعی (AI Lab + Visual Core + Social Agent Demo)
- `/store` خرید سرویس‌ها (Checkout + PayPal optional)
- `/hosting` هاست + دامنه + مسیر اتصال
- `/onboarding` فرم شروع اتصال و قوانین

---

## تنظیم PayPal (اختیاری)
یک فایل `.env.local` بسازید و موارد زیر را قرار دهید:

```env
NEXT_PUBLIC_PAYPAL_CLIENT_ID=YOUR_PAYPAL_CLIENT_ID
PAYPAL_CLIENT_ID=YOUR_PAYPAL_CLIENT_ID
PAYPAL_CLIENT_SECRET=YOUR_PAYPAL_CLIENT_SECRET

# sandbox default (for testing)
PAYPAL_BASE_URL=https://api-m.sandbox.paypal.com
```

> برای محیط واقعی، PAYPAL_BASE_URL را به endpoint تولید تغییر دهید (PayPal Live).
> این پروژه به‌صورت پیش‌فرض Sandbox است.

---

## Webhook Meta (Instagram / WhatsApp) — اسکلت
مسیر:
- `/api/webhooks/meta/messages`

این route هم `GET` برای verify و هم `POST` برای دریافت event ها را دارد.
برای فعال‌سازی واقعی باید:
- `META_VERIFY_TOKEN`
- `META_APP_SECRET` (اختیاری برای signature)
- و تنظیمات Webhooks در Meta Developer

را اضافه کنید.

---

## Deploy
این پروژه برای deploy روی Vercel یا هر Node host مناسب است.

موفق باشید 🌿
