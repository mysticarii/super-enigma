"use client";

import { useMemo, useState } from "react";
import CheckoutModal, { Product } from "@/components/CheckoutModal";
import Link from "next/link";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

export default function StorePage() {
  const products = useMemo<Product[]>(
    () => [
      {
        id: "whatsapp-instagram-ai",
        title: "Instagram + WhatsApp AI Sales Agent",
        priceUsd: 499,
        desc: "فروشنده هوشمند دایرکت + واتساپ با قوانین، هندآف به اپراتور، و گزارش KPI/ROI.",
        features: [
          "سناریوی شلوغی/آفلاین",
          "پاسخ بر اساس کاتالوگ و قوانین",
          "انتقال به اپراتور + خلاصه مکالمه",
          "گزارش اولیه KPI و ROI",
        ],
      },
      {
        id: "site-2026",
        title: "سایت ۲۰۲۶ برای آنلاین‌شاپ",
        priceUsd: 899,
        desc: "طراحی و پیاده‌سازی سایت سطح بالا (Bento + Motion + SEO + سرعت) برای برند شما.",
        features: [
          "Next.js + RTL + Performance",
          "Landing فروش‌ساز + صفحات کلیدی",
          "انیمیشن‌های کنترل‌شده",
          "آماده برای توسعه و مقیاس",
        ],
      },
      {
        id: "hosting-domain-setup",
        title: "هاست + دامنه + اتصال کامل",
        priceUsd: 249,
        desc: "راه‌اندازی، اتصال دامنه، SSL، DNS، و تحویل آماده.",
        features: [
          "راهنمای انتخاب/اتصال دامنه",
          "تنظیم DNS و SSL",
          "تحویل نهایی + چک لیست",
          "پشتیبانی راه‌اندازی",
        ],
      },
    ],
    []
  );

  const [open, setOpen] = useState(false);
  const [p, setP] = useState<Product | null>(null);

  return (
    <>
      <Navbar />
      <main>
        <section style={{ paddingTop: 90 }}>
          <div className="container">
            <div className="section-header">
              <h1 className="section-title">
                <span className="highlight">خرید</span> سرویس‌ها
              </h1>
              <p className="section-subtitle">
                انتخاب کنید، پرداخت ارزی انجام دهید (اختیاری)، سپس وارد مرحله اتصال (Onboarding) می‌شوید.
              </p>
            </div>

            <div className="pricingGrid">
              {products.map((x, i) => (
                <div key={x.id} className={`priceCard ${i === 0 ? "featured" : ""}`}>
                  <div className="priceTop">
                    <h3 style={{ margin: 0 }}>{x.title}</h3>
                    <span className="pill">{i === 0 ? "پرفروش" : "سرویس"}</span>
                  </div>

                  <p style={{ color: "rgba(234,234,240,0.75)", lineHeight: 1.9, marginTop: 10 }}>
                    {x.desc}
                  </p>

                  <div className="price">${x.priceUsd}</div>

                  <ul className="features">
                    {x.features.map((f) => (
                      <li key={f}>{f}</li>
                    ))}
                  </ul>

                  <button
                    className="ai-entry-btn priceBtn"
                    onClick={() => {
                      setP(x);
                      setOpen(true);
                    }}
                  >
                    خرید / شروع
                  </button>

                  {x.id === "whatsapp-instagram-ai" && (
                    <div className="note" style={{ marginTop: 10 }}>
                      می‌خوای اول دمو ببینی؟ <Link href="/ai">برو AI Lab</Link>
                    </div>
                  )}
                </div>
              ))}
            </div>

            <div className="note" style={{marginTop:14, textAlign:"center"}}>
              پرداخت ریالی/تومانی در این نسخه ارائه نمی‌شود. پرداخت ارزی (PayPal در صورت پیکربندی) یا روش‌های قراردادی.
            </div>
          </div>
        </section>

        <CheckoutModal open={open} onClose={() => setOpen(false)} product={p} />
      </main>
      <Footer />
    </>
  );
}
