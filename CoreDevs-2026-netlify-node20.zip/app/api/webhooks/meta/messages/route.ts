import { NextResponse } from "next/server";
import crypto from "crypto";

/**
 * Meta Webhooks skeleton (Instagram / WhatsApp)
 * Path: /api/webhooks/meta/messages
 *
 * For real production:
 * - Set META_VERIFY_TOKEN
 * - Optionally verify signature with META_APP_SECRET using 'x-hub-signature-256'
 *
 * Docs: Meta Webhooks verification + signature validation.
 */

function timingSafeEqual(a: string, b: string) {
  const ba = Buffer.from(a);
  const bb = Buffer.from(b);
  if (ba.length !== bb.length) return false;
  return crypto.timingSafeEqual(ba, bb);
}

function verifySignature(rawBody: string, signatureHeader: string | null) {
  const secret = process.env.META_APP_SECRET;
  if (!secret) return true; // allow if not configured (demo mode)
  if (!signatureHeader) return false;

  // expected format: "sha256=<hex>"
  const [algo, signature] = signatureHeader.split("=");
  if (algo !== "sha256" || !signature) return false;

  const hmac = crypto.createHmac("sha256", secret).update(rawBody).digest("hex");
  return timingSafeEqual(hmac, signature);
}

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);

  const mode = searchParams.get("hub.mode");
  const token = searchParams.get("hub.verify_token");
  const challenge = searchParams.get("hub.challenge");

  const verifyToken = process.env.META_VERIFY_TOKEN;

  if (mode === "subscribe" && token && verifyToken && token === verifyToken) {
    return new NextResponse(challenge || "", { status: 200 });
  }
  return new NextResponse("Forbidden", { status: 403 });
}

export async function POST(req: Request) {
  try {
    const raw = await req.text();
    const sig = req.headers.get("x-hub-signature-256");

    if (!verifySignature(raw, sig)) {
      return NextResponse.json({ error: "Invalid signature" }, { status: 401 });
    }

    const body = JSON.parse(raw);

    // Demo log (in production: route to queue/DB + trigger agent)
    console.log("[META_WEBHOOK]", JSON.stringify(body).slice(0, 1000));

    return NextResponse.json({ ok: true });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || "Server error" }, { status: 500 });
  }
}
