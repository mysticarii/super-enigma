import { NextResponse } from "next/server";

function paypalBaseUrl() {
  // sandbox by default
  return process.env.PAYPAL_BASE_URL || "https://api-m.sandbox.paypal.com";
}

async function getAccessToken() {
  const clientId = process.env.PAYPAL_CLIENT_ID;
  const secret = process.env.PAYPAL_CLIENT_SECRET;
  if (!clientId || !secret) throw new Error("PayPal credentials missing");

  const auth = Buffer.from(`${clientId}:${secret}`).toString("base64");

  const res = await fetch(`${paypalBaseUrl()}/v1/oauth2/token`, {
    method: "POST",
    headers: {
      Authorization: `Basic ${auth}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: "grant_type=client_credentials",
    cache: "no-store",
  });

  const data = await res.json();
  if (!res.ok) throw new Error(data?.error_description || "PayPal auth failed");
  return data.access_token as string;
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const amount = Number(body?.amountUsd || 0);
    const title = String(body?.title || "CoreDevs Service");

    if (!amount || amount <= 0) {
      return NextResponse.json({ error: "Invalid amount" }, { status: 400 });
    }

    const token = await getAccessToken();

    const orderRes = await fetch(`${paypalBaseUrl()}/v2/checkout/orders`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        intent: "CAPTURE",
        purchase_units: [
          {
            description: title,
            amount: { currency_code: "USD", value: amount.toFixed(2) },
          },
        ],
      }),
      cache: "no-store",
    });

    const order = await orderRes.json();
    if (!orderRes.ok) {
      return NextResponse.json({ error: order?.message || "Create order failed" }, { status: 400 });
    }

    return NextResponse.json({ id: order.id });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || "Server error" }, { status: 500 });
  }
}
