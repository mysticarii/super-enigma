import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const body = await req.json();

    const name = String(body?.name || "").trim();
    const email = String(body?.email || "").trim();
    const instagram = String(body?.instagram || "").trim();
    const whatsapp = String(body?.whatsapp || "").trim();
    const message = String(body?.message || "").trim();

    if (!name || !email || !message) {
      return NextResponse.json({ error: "نام، ایمیل و پیام الزامی است." }, { status: 400 });
    }

    // Demo: in real system, store to DB / send to CRM
    console.log("[CONTACT]", { name, email, instagram, whatsapp, message, at: new Date().toISOString() });

    return NextResponse.json({ ok: true });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || "Server error" }, { status: 500 });
  }
}
