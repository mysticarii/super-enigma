import dynamic from "next/dynamic";
import Link from "next/link";
import SocialAgentDemo from "@/components/SocialAgentDemo";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

const AIVisualCore = dynamic(() => import("@/components/AIVisualCore"), { ssr: false });

export default function AIPage() {
  return (
    <>
      <Navbar />
      <main>
        <section className="aiHero">
          <div className="container">
            <div className="aiHeroGrid">
              <div className="aiHeroCopy">
                <div className="aiKicker">AI Lab • Instagram + WhatsApp</div>
                <h1 className="aiHeroTitle">
                  <span className="highlight">فروشنده‌ی هوشمند</span> برای دایرکت و واتساپ آنلاین‌شاپ
                </h1>

                <p className="aiHeroText">
                  وقتی شلوغید یا آفلاین هستید، AI طبق «قوانین فروشگاه» گفتگو را جلو می‌برد:
                  موجودی/قیمت را از روی کاتالوگ چک می‌کند، اطلاعات سفارش را جمع می‌کند، پیش‌فاکتور می‌سازد
                  و در صورت ابهام، کار را به اپراتور منتقل می‌کند — با کمترین خطا و قابل گزارش.
                </p>

                <div className="aiHeroActions">
                  <Link className="ai-entry-btn" href="/onboarding?product=whatsapp-instagram-ai">
                    شروع پایلوت دایرکت + واتساپ
                  </Link>
                  <Link className="hero-btn-outline" href="/store">
                    دیدن پلن‌ها و خرید
                  </Link>
                </div>

                <div className="aiTrustRow">
                  <div className="aiTrustCard">✅ Rules / Policies</div>
                  <div className="aiTrustCard">✅ Human Handoff</div>
                  <div className="aiTrustCard">✅ KPI Dashboard</div>
                  <div className="aiTrustCard">✅ Multi-language</div>
                </div>
              </div>

              <div className="aiHeroVisual">
                <AIVisualCore />
                <div className="aiVisualOverlay">
                  <div className="aiHud">
                    <div className="aiHudItem"><span className="dot ok" /> Instagram DM</div>
                    <div className="aiHudItem"><span className="dot ok" /> WhatsApp</div>
                    <div className="aiHudItem"><span className="dot ok" /> Guardrails</div>
                    <div className="aiHudItem"><span className="dot ok" /> Logs</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="aiSection">
          <div className="container">
            <div className="section-header">
              <h2 className="section-title"><span className="highlight">چطور</span> فروش را جلو می‌برد؟</h2>
              <p className="section-subtitle">
                اینجا “چت‌بات” نیست؛ یک Agent فروش با ورودی/خروجی مشخص است.
              </p>
            </div>

            <div className="bentoGrid">
              <div className="bento">
                <h3>۱) فهم نیت مشتری</h3>
                <p>قیمت/موجودی، ثبت سفارش، پیگیری، مرجوعی… دسته‌بندی و مسیر درست.</p>
              </div>
              <div className="bento">
                <h3>۲) پاسخ از روی دیتای واقعی</h3>
                <p>کاتالوگ/قوانین → جلوگیری از وعده اشتباه یا اطلاعات قدیمی.</p>
              </div>
              <div className="bento">
                <h3>۳) جمع‌آوری سفارش</h3>
                <p>نام، شهر، آدرس کوتاه، رنگ/سایز → ساخت پیش‌فاکتور یا پیش‌نویس سفارش.</p>
              </div>
              <div className="bento">
                <h3>۴) کنترل ریسک</h3>
                <p>Approval برای پیام‌های حساس + هندآف به اپراتور وقتی ابهام باشد.</p>
              </div>
            </div>
          </div>
        </section>

        <section className="aiSection" style={{ background: "var(--primary-dark)" }}>
          <div className="container">
            <SocialAgentDemo />
          </div>
        </section>

        <section className="aiFinalCta">
          <div className="container">
            <div className="aiFinalCard">
              <h2 style={{ margin: 0 }}>می‌خوای آنلاین‌شاپت حتی وقتی آفلاینی بفروشه؟</h2>
              <p style={{ color: "rgba(234,234,240,0.75)", marginTop: 10 }}>
                ۱۴ روز پایلوت: اتصال کانال‌ها، قوانین، سناریوها، و گزارش اولیه KPI.
              </p>
              <div style={{ display: "flex", gap: 12, flexWrap: "wrap", justifyContent: "center", marginTop: 14 }}>
                <Link className="ai-entry-btn" href="/onboarding?product=whatsapp-instagram-ai">شروع پایلوت</Link>
                <Link className="hero-btn-outline" href="/hosting">دامنه/هاست هم می‌خوام</Link>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
