"use client";

import { useMemo, useState } from "react";
import CheckoutModal, { Product } from "@/components/CheckoutModal";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

export default function HostingPage() {
  const product = useMemo<Product>(
    () => ({
      id: "hosting-domain-setup",
      title: "هاست + دامنه + اتصال کامل",
      priceUsd: 249,
      desc: "از انتخاب تا اتصال DNS/SSL و تحویل سایت روی دامنه شما.",
      features: [
        "چک لیست اتصال DNS",
        "SSL و امنیت پایه",
        "تحویل نهایی و تست",
        "پشتیبانی راه‌اندازی",
      ],
    }),
    []
  );

  const [domain, setDomain] = useState("");
  const [checked, setChecked] = useState<{ ok: boolean; msg: string } | null>(null);
  const [open, setOpen] = useState(false);

  function fakeCheck() {
    const d = domain.trim().toLowerCase();
    if (!d || !d.includes(".")) {
      setChecked({ ok: false, msg: "دامنه معتبر وارد کنید (مثلاً example.com)" });
      return;
    }
    const ok = Math.random() > 0.35;
    setChecked(
      ok
        ? { ok: true, msg: "به نظر قابل ثبت/استفاده است (برای نتیجه قطعی باید از API رجیسترار چک شود)." }
        : { ok: false, msg: "احتمالاً قبلاً ثبت شده. چند گزینه دیگر امتحان کن." }
    );
  }

  return (
    <>
      <Navbar />
      <main>
        <section style={{ paddingTop: 90 }}>
          <div className="container">
            <div className="section-header">
              <h1 className="section-title">
                <span className="highlight">هاست و دامنه</span> + اتصال کامل
              </h1>
              <p className="section-subtitle">
                مشتری باید اینجا حس کند «هم خرید هست، هم اتصال، هم تحویل».
              </p>
            </div>

            <div className="hostingGrid">
              <div className="card">
                <h3 style={{ marginTop: 0 }}>۱) بررسی دامنه</h3>
                <p>دامنه را وارد کن تا مسیر اتصال و تحویل را شروع کنیم.</p>

                <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginTop: 12 }}>
                  <input
                    value={domain}
                    onChange={(e) => setDomain(e.target.value)}
                    placeholder="example.com"
                    style={{ flex: 1, minWidth: 220 }}
                  />
                  <button className="ai-entry-btn" onClick={fakeCheck}>
                    بررسی
                  </button>
                </div>

                {checked && (
                  <div className="note" style={{ marginTop: 10 }}>
                    {checked.ok ? "✅ " : "❌ "}
                    {checked.msg}
                  </div>
                )}
              </div>

              <div className="card">
                <h3 style={{ marginTop: 0 }}>۲) مسیر اتصال (Wizard)</h3>
                <p>
                  بعد از خرید، Onboarding داریم:
                  DNS/NS → SSL → Deploy → تایید نهایی.
                </p>

                <div className="bentoMini">
                  <div className="miniStep">DNS / NS</div>
                  <div className="miniStep">SSL</div>
                  <div className="miniStep">Deploy</div>
                  <div className="miniStep">Verify</div>
                </div>

                <div style={{ marginTop: 12 }}>
                  <button
                    className="ai-entry-btn"
                    onClick={() => setOpen(true)}
                    style={{ width: "100%", justifyContent: "center" }}
                  >
                    خرید سرویس اتصال (${product.priceUsd})
                  </button>
                </div>

                <div className="note">
                  اگر سایت ندارید، پلن «سایت ۲۰۲۶» را از صفحه خرید انتخاب کنید.
                </div>
              </div>

              <div className="card">
                <h3 style={{ marginTop: 0 }}>۳) استاندارد تحویل ۲۰۲۶</h3>
                <ul className="features">
                  <li>سرعت، سکیوریتی، ریسپانسیو</li>
                  <li>SEO پایه + Analytics</li>
                  <li>نسخه موبایل اول</li>
                  <li>چک لیست تحویل و تست</li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        <CheckoutModal open={open} onClose={() => setOpen(false)} product={product} />
      </main>
      <Footer />
    </>
  );
}
