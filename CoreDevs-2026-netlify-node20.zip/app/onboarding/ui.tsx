"use client";

import { useMemo, useState } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

export default function OnboardingClient({ product }: { product: string }) {
  const title = useMemo(() => {
    if (product.includes("whatsapp") || product.includes("instagram")) return "Onboarding اینستاگرام + واتساپ AI";
    if (product.includes("hosting")) return "Onboarding دامنه/هاست";
    if (product.includes("site")) return "Onboarding ساخت سایت ۲۰۲۶";
    return "Onboarding";
  }, [product]);

  const [data, setData] = useState({
    business: "",
    platform: "Instagram + WhatsApp",
    instagram: "",
    whatsapp: "",
    domain: "",
    goals: "",
    busyHours: "18-23",
    policyMode: "strict",
    catalogSource: "sheet",
  });

  const [done, setDone] = useState(false);

  return (
    <>
      <Navbar />
      <main>
        <section style={{ paddingTop: 90 }}>
          <div className="container">
            <div className="section-header">
              <h1 className="section-title">
                <span className="highlight">{title}</span>
              </h1>
              <p className="section-subtitle">
                بعد از شروع/خرید، اینجا اطلاعات لازم برای اتصال کانال‌ها و تعریف قوانین فروش جمع‌آوری می‌شود.
              </p>
            </div>

            <div className="onboardGrid">
              <div className="form">
                <div className="formRow">
                  <input
                    placeholder="نام آنلاین‌شاپ"
                    value={data.business}
                    onChange={(e) => setData((v) => ({ ...v, business: e.target.value }))}
                  />
                  <select
                    value={data.platform}
                    onChange={(e) => setData((v) => ({ ...v, platform: e.target.value }))}
                    className="select"
                  >
                    <option>Instagram + WhatsApp</option>
                    <option>WooCommerce</option>
                    <option>Shopify</option>
                    <option>Custom</option>
                  </select>
                </div>

                <div className="formRow" style={{ marginTop: 10 }}>
                  <input
                    placeholder="Instagram username (مثلاً @shop)"
                    value={data.instagram}
                    onChange={(e) => setData((v) => ({ ...v, instagram: e.target.value }))}
                  />
                  <input
                    placeholder="WhatsApp Business (شماره/ID)"
                    value={data.whatsapp}
                    onChange={(e) => setData((v) => ({ ...v, whatsapp: e.target.value }))}
                  />
                </div>

                <div className="formRow" style={{ marginTop: 10 }}>
                  <select
                    value={data.catalogSource}
                    onChange={(e) => setData((v) => ({ ...v, catalogSource: e.target.value }))}
                    className="select"
                  >
                    <option value="sheet">کاتالوگ: Google Sheet / Excel</option>
                    <option value="csv">کاتالوگ: CSV</option>
                    <option value="api">کاتالوگ: API / WooCommerce</option>
                  </select>

                  <input
                    placeholder="ساعت‌های شلوغی (مثلاً 18-23)"
                    value={data.busyHours}
                    onChange={(e) => setData((v) => ({ ...v, busyHours: e.target.value }))}
                  />
                </div>

                <div className="formRow" style={{ marginTop: 10 }}>
                  <select
                    value={data.policyMode}
                    onChange={(e) => setData((v) => ({ ...v, policyMode: e.target.value }))}
                    className="select"
                  >
                    <option value="strict">Strict (کمترین خطا، سوال بیشتر)</option>
                    <option value="balanced">Balanced (متعادل)</option>
                    <option value="fast">Fast (سریع‌تر، هندآف بیشتر)</option>
                  </select>

                  <input
                    placeholder="دامنه (اختیاری)"
                    value={data.domain}
                    onChange={(e) => setData((v) => ({ ...v, domain: e.target.value }))}
                  />
                </div>

                <div style={{ marginTop: 10 }}>
                  <textarea
                    placeholder="اهداف: افزایش فروش؟ کاهش پیام‌های تکراری؟ جمع‌آوری سفارش در زمان شلوغی؟"
                    value={data.goals}
                    onChange={(e) => setData((v) => ({ ...v, goals: e.target.value }))}
                  />
                </div>

                <div style={{ marginTop: 12, display: "flex", gap: 10, flexWrap: "wrap" }}>
                  <button className="ai-entry-btn" onClick={() => setDone(true)}>
                    ثبت و شروع اتصال
                  </button>
                  <a className="hero-btn-outline" href="/ai">
                    دیدن AI Lab
                  </a>
                </div>

                {done && (
                  <div className="note" style={{ marginTop: 12 }}>
                    ✅ ثبت شد. قدم بعدی: اتصال کانال‌ها + قوانین + تست سناریوهای «شلوغی/آفلاین».
                  </div>
                )}
              </div>

              <div className="card">
                <h3 style={{ marginTop: 0 }}>چک‌لیست اجرای اینستاگرام/واتساپ AI</h3>
                <ul className="features">
                  <li>تعریف قوانین: قیمت، ارسال، مرجوعی، پرداخت، تخفیف</li>
                  <li>اتصال کاتالوگ (Google Sheet / CSV / API)</li>
                  <li>حالت شلوغی: پاسخ کوتاه + جمع‌آوری سفارش</li>
                  <li>حالت آفلاین: پیش‌نویس سفارش + زمان‌بندی پاسخ</li>
                  <li>هندآف به اپراتور + خلاصه مکالمه</li>
                  <li>داشبورد KPI: زمان پاسخ، نرخ تبدیل، فروش کمکی</li>
                </ul>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
