import OnboardingClient from "./ui";

export default function OnboardingPage({
  searchParams,
}: {
  searchParams?: { product?: string };
}) {
  const product = searchParams?.product ?? "whatsapp-instagram-ai";
  return <OnboardingClient product={product} />;
}
