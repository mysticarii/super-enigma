// Netlify/CI friendly shim:
// If TypeScript can't resolve Three.js typings in the build environment,
// this prevents `next build` from failing.
declare module "three";
